public class main {
    public static void(Strings arg[]) {
        IDictionary dict = new IDictionary();
        IDictionary dico = new OrderedDictionary();
        
        

    }
}